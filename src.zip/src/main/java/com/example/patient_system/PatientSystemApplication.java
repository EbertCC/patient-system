package com.example.patient_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientSystemApplication {
	public static void main(String[] args) {
		SpringApplication.run(PatientSystemApplication.class, args);
	}
}